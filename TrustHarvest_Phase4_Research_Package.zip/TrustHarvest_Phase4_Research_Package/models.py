from datetime import datetime, timezone
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy import inspect, text
from werkzeug.security import generate_password_hash, check_password_hash

db = SQLAlchemy()

def utcnow():
    return datetime.now(timezone.utc)

class User(db.Model):
    __tablename__ = 'users'
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False, index=True)
    password_hash = db.Column(db.String(256), nullable=False)
    role = db.Column(db.String(20), nullable=False) # admin, farmer, transporter, retailer, customer
    full_name = db.Column(db.String(120), nullable=True)
    contact = db.Column(db.String(120), nullable=True)
    created_at = db.Column(db.DateTime, default=utcnow)

    def __init__(self, **kwargs):
        super().__init__(**kwargs)

    def set_password(self, password):
        self.password_hash = generate_password_hash(password)

    def check_password(self, password):
        return check_password_hash(self.password_hash, password)


class Product(db.Model):
    __tablename__ = 'products'
    id = db.Column(db.Integer, primary_key=True)
    batch_id = db.Column(db.String(64), unique=True, nullable=False, index=True)
    name = db.Column(db.String(120), nullable=False)
    quantity = db.Column(db.String(50), nullable=False)
    farming_method = db.Column(db.String(100), nullable=False)
    packaging_date = db.Column(db.String(50), nullable=False)
    farmer_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    image = db.Column(db.String(255), nullable=False)
    qr_code = db.Column(db.String(255), nullable=True)
    on_chain_hash = db.Column(db.String(66), nullable=True)
    tx_hash = db.Column(db.String(80), nullable=True)
    block_number = db.Column(db.Integer, nullable=True)
    contract_address = db.Column(db.String(64), nullable=True)
    contract_version = db.Column(db.String(10), nullable=True)
    signer_address = db.Column(db.String(64), nullable=True)
    status = db.Column(db.String(50), default='Harvested') # Harvested, In Transit, Delivered to Retail, In Stock, Sold
    created_at = db.Column(db.DateTime, default=utcnow)

    farmer = db.relationship('User', foreign_keys=[farmer_id], backref='farmer_products')
    farmer_data = db.relationship('FarmerData', backref='product', uselist=False, cascade='all, delete-orphan')
    transport_data = db.relationship(
        'TransportData',
        backref='product',
        cascade='all, delete-orphan',
        order_by='(TransportData.timestamp.asc(), TransportData.id.asc())'
    )
    retail_data = db.relationship('RetailData', backref='product', uselist=False, cascade='all, delete-orphan')
    stage_snapshots = db.relationship('StageSnapshot', backref='product', cascade='all, delete-orphan', order_by='StageSnapshot.id.asc()')

    def __init__(self, **kwargs):
        super().__init__(**kwargs)


class FarmerData(db.Model):
    __tablename__ = 'farmer_data'
    id = db.Column(db.Integer, primary_key=True)
    product_id = db.Column(db.Integer, db.ForeignKey('products.id'), nullable=False)
    farm_name = db.Column(db.String(120), nullable=True)
    farm_location = db.Column(db.String(150), nullable=True)
    harvest_date = db.Column(db.String(50), nullable=True)
    certifications = db.Column(db.String(200), nullable=True)
    notes = db.Column(db.Text, nullable=True)
    created_at = db.Column(db.DateTime, default=utcnow)

    def __init__(self, **kwargs):
        super().__init__(**kwargs)


class TransportData(db.Model):
    __tablename__ = 'transport_data'
    id = db.Column(db.Integer, primary_key=True)
    product_id = db.Column(db.Integer, db.ForeignKey('products.id'), nullable=False)
    transporter_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    status = db.Column(db.String(50), nullable=False) # Picked Up, In Transit, Customs Cleared, Delivered
    current_location = db.Column(db.String(150), nullable=False)
    temperature = db.Column(db.String(50), nullable=True)
    vehicle_number = db.Column(db.String(50), nullable=True)
    notes = db.Column(db.Text, nullable=True)
    on_chain_hash = db.Column(db.String(66), nullable=True)
    tx_hash = db.Column(db.String(80), nullable=True)
    block_number = db.Column(db.Integer, nullable=True)
    signer_address = db.Column(db.String(64), nullable=True)
    timestamp = db.Column(db.DateTime, default=utcnow)

    transporter = db.relationship('User', foreign_keys=[transporter_id])

    def __init__(self, **kwargs):
        super().__init__(**kwargs)


class RetailData(db.Model):
    __tablename__ = 'retail_data'
    id = db.Column(db.Integer, primary_key=True)
    product_id = db.Column(db.Integer, db.ForeignKey('products.id'), nullable=False)
    retailer_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    store_name = db.Column(db.String(120), nullable=True)
    store_location = db.Column(db.String(150), nullable=True)
    price = db.Column(db.Float, nullable=True)
    stock_quantity = db.Column(db.String(50), nullable=True)
    arrival_date = db.Column(db.String(50), nullable=True)
    shelf_life = db.Column(db.String(50), nullable=True)
    on_chain_hash = db.Column(db.String(66), nullable=True)
    tx_hash = db.Column(db.String(80), nullable=True)
    block_number = db.Column(db.Integer, nullable=True)
    signer_address = db.Column(db.String(64), nullable=True)
    updated_at = db.Column(db.DateTime, default=utcnow, onupdate=utcnow)

    retailer = db.relationship('User', foreign_keys=[retailer_id])

    def __init__(self, **kwargs):
        super().__init__(**kwargs)


class StageSnapshot(db.Model):
    """
    Immutable initial snapshot of stage fields captured strictly at initial blockchain
    anchoring. Never modified by tamper simulators; always re-validated by recomputing
    the SHA-256 hash against the actual blockchain record before displaying diffs or restoring.
    """
    __tablename__ = 'stage_snapshots'
    id = db.Column(db.Integer, primary_key=True)
    product_id = db.Column(db.Integer, db.ForeignKey('products.id'), nullable=False, index=True)
    stage = db.Column(db.String(20), nullable=False, index=True)  # HARVEST, TRANSPORT, RETAIL
    transport_id = db.Column(db.Integer, db.ForeignKey('transport_data.id'), nullable=True, index=True)
    original_hash = db.Column(db.String(66), nullable=False, index=True)
    snapshot_json = db.Column(db.Text, nullable=False)
    created_at = db.Column(db.DateTime, default=utcnow)

    transport_record = db.relationship(
        'TransportData',
        foreign_keys=[transport_id],
        backref=db.backref('snapshots', cascade='all, delete-orphan'),
    )

    def __init__(self, **kwargs):
        super().__init__(**kwargs)


def ensure_schema_columns():
    """
    Idempotent schema upgrader: adds newly introduced blockchain receipt/version columns
    to existing tables without wiping existing user/product records (SQLite & PostgreSQL).
    """
    engine = db.engine
    inspector = inspect(engine)
    existing_tables = set(inspector.get_table_names())

    expected_columns = {
        'products': [
            ('tx_hash', 'VARCHAR(80)'),
            ('block_number', 'INTEGER'),
            ('contract_address', 'VARCHAR(64)'),
            ('contract_version', 'VARCHAR(10)'),
            ('signer_address', 'VARCHAR(64)'),
        ],
        'transport_data': [
            ('on_chain_hash', 'VARCHAR(66)'),
            ('tx_hash', 'VARCHAR(80)'),
            ('block_number', 'INTEGER'),
            ('signer_address', 'VARCHAR(64)'),
        ],
        'retail_data': [
            ('on_chain_hash', 'VARCHAR(66)'),
            ('tx_hash', 'VARCHAR(80)'),
            ('block_number', 'INTEGER'),
            ('signer_address', 'VARCHAR(64)'),
        ],
    }

    with engine.begin() as conn:
        for table_name, cols in expected_columns.items():
            if table_name not in existing_tables:
                continue
            existing_names = {col['name'] for col in inspector.get_columns(table_name)}
            for col_name, col_type in cols:
                if col_name not in existing_names:
                    conn.execute(text(f"ALTER TABLE {table_name} ADD COLUMN {col_name} {col_type}"))
