# TrustHarvest Phase 4 Research Handover Document

## 1. Executive Summary & Repository Metadata
- **Project**: TrustHarvest — Decentralized Agricultural Supply Chain Provenance System
- **Repository**: https://github.com/DakshDhaundiyal/blockchain.git
- **Git Branch**: `research/phase4-baseline-experiments`
- **Commit Hash**: `3c596359b9459e7170ed59d20154378b370a10f5`
- **Environment**:
  - Python: `3.11.9`
  - Solidity: `solc 0.8.19` (py-solc-x) / `0.8.20`
  - Ganache: `v7.9.2` (@ganache/cli: 0.10.2, @ganache/core: 0.10.2)
  - EVM Chain ID: `1337` (Network ID: 1337)
  - Active Contract Address: `0x6bbAcD565E12B91E9214E5e00650D46d4b13676E` (Contract Version: V2)
  - Isolated Research Database: `research/phase4/data/research_phase4.db`

---

## 2. Implemented Features & Architecture
TrustHarvest provides end-to-end food provenance tracking using a hybrid Web2/Web3 architecture:
1. **Relational Database Tier**: SQLite storing entity records across `products`, `farmer_data`, `transport_data`, and `retail_data`.
2. **Deterministic Hashing Engine**: SHA-256 state serialization using pipe-delimited canonical representations:
   - Harvest: `batch_id|product_name|quantity|farming_method|harvest_date|packaging_date`
   - Transport: `batch_id|stage_name|location|temperature|vehicle_number`
   - Retail: `batch_id|store_name|location|price|stock_quantity|arrival_date|shelf_life`
3. **Smart Contract Tier (`TrustHarvestV2.sol`)**:
   - `storeHash(batchId, hash)`: Anchors harvest batch root hash.
   - `addStageHash(batchId, stage, hash)`: Records sequential supply chain checkpoint hashes.
   - `verifyBatch(batchId, clientHash)`: Constant-time comparison between stored root and client state.
   - `getBatchStages(batchId)`: Retrieves on-chain checkpoint stage tuples.
4. **Three-State Verification Pipeline**:
   - `verified`: On-chain hash matches local state.
   - `tampered`: Local hash mismatches on-chain record.
   - `cannot_verify`: Graceful degradation upon network outages, node timeouts, missing anchors, or invalid signatures.
5. **Local Snapshot Engine**:
   - Off-chain JSON snapshots stored in `stage_snapshots` capture point-in-time state upon stage commitment.
   - Snapshot hash is validated against on-chain hash to provide collision-resistant field-level discrepancy attribution.

---

## 3. Actual Experimental Trial Counts & Verified Metrics (E1–E6)

| Experiment | Focus | Trials | Success Rate | Detection Rate | Mean Latency | Key Empirical Finding |
| :--- | :--- | :---: | :---: | :---: | :---: | :--- |
| **E1** | Baseline Authenticity | 120 | 100.0% | N/A (0 tampered) | 169.49 ms | 100% verification accuracy on unmodified records. |
| **E2** | Controlled Tampering | 290 | 100.0% | 100.0% (250/250) | 525.95 ms | 100% sensitivity on hashed fields; 0 false alarms on unhashed fields. |
| **E3** | Snapshot Diagnosis | 80 | 100.0% | 100.0% | 212.44 ms | 100% field diagnostic F1 score; DB+snapshot collusion defeated. |
| **E4** | Failure Modes & Robustness | 50 | 90.0%* | N/A (0 false alerts) | 184.20 ms | 0 false tamper alerts under RPC loss/reverts; positional vulnerability identified. |
| **E5** | Multi-Checkpoint Scaling | 30 | 100.0% | 100.0% | 285.98 ms | Linear O(N) latency growth (~22.5 ms per additional checkpoint). |
| **E6** | Performance & Scalability | 1,170 | 100.0% | N/A (authentic set) | 214.28 ms | 2.01–2.36 batches/sec throughput; 99.8% latency spent in RPC I/O. |
| **Total** | **All Trials Audited** | **1,740** | — | — | — | **All raw CSVs and summary JSONs match 100%**. |

*\*Note on E4: 45/50 matched expected output; 5 trials in scenario e4_3_extra_transport_onchain produced tampered instead of cannot_verify due to positional array-index alignment shift.*

---

## 4. Gas & Performance Measurements

### 4.1 Smart Contract Gas Consumption
- `storeHash()`: **163,382 gas** (14-char batch ID) / **163,442 gas** (18-char batch ID).
- `addStageHash()`: **190,612 gas** (14-char batch ID) / **190,672 gas** (18-char batch ID).
- Calldata delta: Exactly +60 gas for +4 characters ($4 \times 16 - 4$ packing adjustment).

### 4.2 Latency Component Decomposition (E6 Benchmark)
- Local SHA-256 CPU hashing: **0.19 ms (0.09%)**
- EVM JSON-RPC Network I/O: **209.23 ms (99.8%)**
- Application Context Logic: **~1.5 ms (0.1%)**
- System Throughput: **2.01 to 2.36 batches/second** on single-threaded synchronous Python.

---

## 5. Security Insights, Vulnerabilities, & Known Limitations
1. **Positional Matching Vulnerability**: Checkpoint matching between local DB and on-chain records relies on sequential array index matching. Appending extraneous on-chain stages shifts array alignment, flagging authentic subsequent stages as `tampered` rather than identifying an unanchored/foreign stage.
2. **Protection Boundaries**: Certain metadata fields (`FarmerData.certifications`, `FarmerData.notes`, `TransportData.timestamp`, `RetailData.updated_at`) are excluded from SHA-256 hashing. Modifying these fields does not trigger tamper alarms.
3. **RPC Roundtrip Bottleneck**: Sequential synchronous `eth_call` RPCs dominate latency (99.8%). High-throughput production deployments require Multicall3 (EIP-1822) or batched RPC multicalls.
4. **Sepolia Deployment**: Gated and unverified. All experimental measurements were conducted on local Ganache (`CHAIN_ID=1337`) in strict adherence to Safety Rule #4.
